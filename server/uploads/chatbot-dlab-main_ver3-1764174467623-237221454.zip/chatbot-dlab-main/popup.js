const API_BACKEND_URL = "http://localhost:3000";
let token = null;

const messagesEl = document.getElementById("chat-messages");
const formEl = document.getElementById("chat-form");
const inputEl = document.getElementById("user-input");

// Giao diện chat
function appendMessage(text, sender, includeImage = false) {
    const wrapper = document.createElement("div");
    wrapper.className = `message ${sender}-message`;

    const bubble = document.createElement("div");
    bubble.textContent = text;
    bubble.className = sender === "bot" ? "bot-message" : "user-message";

    wrapper.appendChild(bubble);

    if (includeImage && sender === "bot") {
        const img = document.createElement("img");
        img.src = chrome.runtime.getURL("icon.png");
        img.className = "avatar";
        wrapper.appendChild(img);
    }

    messagesEl.appendChild(wrapper);
    messagesEl.scrollTop = messagesEl.scrollHeight;
}

// Gửi prompt đến server backend (chuyển tiếp đến Gemini API)
async function sendMessage(question) {
    appendMessage(question, "user");
    inputEl.value = "";

    if (!token) {
        appendMessage("Không có token hợp lệ.", "bot", true);
        return;
    }

    try {
        const res = await fetch(`${API_BACKEND_URL}/api/ask`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ prompt: question, token })
        });

        const data = await res.json();
        const reply = data.reply || "Không có phản hồi.";
        appendMessage(reply, "bot", true);
    } catch (error) {
        appendMessage("Lỗi khi kết nối với server.", "bot", true);
        console.error(error);
    }
}

// Sự kiện gửi form
formEl.addEventListener("submit", (e) => {
    e.preventDefault();
    const question = inputEl.value.trim();
    if (question) sendMessage(question);
});

// Lấy token khi mở popup
async function getToken() {
    try {
        const res = await fetch(`${API_BACKEND_URL}/get-token`, {
            method: "POST"
        });
        const data = await res.json();
        token = data.token;
        console.log("Token được cấp:", token);
    } catch (err) {
        console.error("Không thể lấy token:", err);
        appendMessage("Không thể kết nối server để lấy token.", "bot", true);
    }
}

// Thu hồi token khi đóng popup
window.addEventListener("beforeunload", async () => {
    if (!token) return;
    try {
        await fetch(`${API_BACKEND_URL}/release-token`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token })
        });
        console.log("Đã thu hồi token.");
    } catch (err) {
        console.warn("Lỗi khi thu hồi token:", err);
    }
});

// Bắt đầu lấy token khi mở popup
getToken();
