const time_left = document.querySelector("#timeleft");
if (time_left)
  (function () {
    const existingChat = document.getElementById("ptit-chat");
    if (existingChat) return;

    const chatContainer = document.createElement("div");
    chatContainer.id = "ptit-chat";

    chatContainer.innerHTML = `
      <div class="ptit-box">
        <div class="ptit-header">
        <h4> Chatbot PTIT </h4>
        </div>
        <div class="ptit-body" id="ptit-chat-body">
          <div class="ptit-message ptit-bot">
            <div class="ptit-text">Xin chào, mình là PTIT, mình có thể giúp gì cho bạn?</div>
            <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
          </div>
        </div>
        <div class="ptit-footer">
          <input id="ptit-chat-input" class="ptit-input" placeholder="Nhập nội dung..." />
          <button id="ptit-send-btn" class="ptit-send-btn" type="submit">➤</button>
        </div>
      </div>

      <style>
      #ptit-chat {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 350px;
        max-height: 500px;
        /* Giới hạn chiều cao khung */
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
        border-radius: 10px;
        overflow: hidden;
        z-index: 9999;
        font-family: Arial, sans-serif;
      }

      .ptit-box {
        display: flex;
        flex-direction: column;
        height: 100%;
        background-color: white;
        border: 2px solid red;
      }

      .ptit-header {
        display: flex;
        justify-content: space-between;
        background-color: red;
        color: white;
        padding: 10px;
        font-weight: bold;
        text-align: center;
      }

      .close-btn{
        cursor: pointer;
      }

      .ptit-body {
        flex: 1;
        overflow-y: auto;
        padding: 10px;
        max-height: 400px;
        /* tạo vùng cuộn */
      }

      .ptit-footer {
        display: flex;
        padding: 10px;
        border-top: 1px solid #ccc;
      }

      .ptit-input {
        flex: 1;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-right: 10px;
      }

      .ptit-send-btn {
        padding: 8px 12px;
        background-color: red;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
      }

      .ptit-message {
        display: flex;
        align-items: flex-start;
        margin-bottom: 10px;
      }

      .ptit-bot {
        flex-direction: row;
      }

      .ptit-user {
        justify-content: flex-end;
      }

      .ptit-text {
        background-color: #f0f0f0;
        padding: 10px;
        border-radius: 8px;
        max-width: 80%;
        word-wrap: break-word;
      }

      .ptit-bot .ptit-text {
        background-color: red;
        color: white;
      }

      .ptit-avatar {
        width: 24px;
        height: 24px;
        margin-left: 5px;
      }
      </style>
    `;
    localStorage.removeItem("ptit-chat-history")
    document.body.appendChild(chatContainer);
    // Get the input field
    const input = document.querySelector("#ptit-chat-input");

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keypress", function (event) {
      // If the user presses the "Enter" key on the keyboard
      if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.querySelector("#ptit-send-btn").click();
      }
    });
    const chatBody = document.getElementById("ptit-chat-body");
    const chatInput = document.getElementById("ptit-chat-input");
    const sendBtn = document.getElementById("ptit-send-btn");

    function saveChat() {
      localStorage.setItem("ptit-chat-history", chatBody.innerHTML);
    }

    function botChat(reply) {
      const botMsg = document.createElement("div");
      botMsg.className = "ptit-message ptit-bot";
      botMsg.innerHTML = `
        <div class="ptit-text">${parseMarkdown(reply)}</div>
        <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
      `;
      chatBody.appendChild(botMsg);
      chatBody.scrollTop = chatBody.scrollHeight;
    }
    function loadChat() {
      const saved = localStorage.getItem("ptit-chat-history");
      if (saved) {
        chatBody.innerHTML = saved;
      }
    }
    // MARKDOWN PARSER
    function parseMarkdown(md) {
      md = md.replace(/```([\s\S]*?)```/g, '<pre class="ptit-code-block"><code>$1</code></pre>');
      md = md.replace(/`([^`]+)`/g, '<code class="ptit-inline-code">$1</code>');
      md = md.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
      md = md.replace(/\*([^*]+)\*/g, '<em>$1</em>');
      md = md.replace(/\n(\d+)\. /g, '<br>$1. ');
      md = md.replace(/\n- /g, '<br>- ');
      md = md.replace(/\n/g, '<br>');
      return md;
    }

    // GỌI GEMINI TRẢ LỜI
    async function callGeminiAPI(question) {
      const API_KEY = "AIzaSyBPfVw0jI5e6dpmg8BY4tNbVFPzGFfN6wI";
      const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

      const body = {
        contents: [{ parts: [{ text: question }] }]
      };

      try {
        const res = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });

        const data = await res.json();
        const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "Không có phản hồi.";

        console.log(`Reply: ${reply}`)
        // const botMsg = document.createElement("div");
        // botMsg.className = "ptit-message ptit-bot";
        // botMsg.innerHTML = `
        //   <div class="ptit-text">${parseMarkdown(reply)}</div>
        //   <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        // `;
        // chatBody.appendChild(botMsg);
        // chatBody.scrollTop = chatBody.scrollHeight;
        botChat(reply)
        saveChat();
      } catch (error) {
        const errorMsg = document.createElement("div");
        errorMsg.className = "ptit-message ptit-bot";
        errorMsg.innerHTML = `
        <div class="ptit-text">Lỗi khi gọi API.</div>
        <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
      `;
        chatBody.appendChild(errorMsg);
      }
    }

    // GỌI GEMINI PHÂN LOẠI Ý ĐỊNH
    async function classifyIntentWithGemini(text) {
      const des = document.querySelector(".submit__des")?.innerText.trim() || "";
      const req = document.querySelector(".submit__req")?.innerText.trim() || "";

      // check if currently in a contest
      // const prompt = `
      // Bạn là một mô hình phân loại câu hỏi. Dựa trên nội dung sau, hãy phân loại nó thành một trong các loại:
      // - "solve_request" nếu người dùng đang yêu cầu giải bài, làm bài.
      // - "chat" nếu là trò chuyện chung, hỏi đáp thông tin.
      // - "other" nếu không rõ hoặc không thuộc hai nhóm trên.

      // Câu hỏi: "${text}"
      // Phân loại:`;

      const prompt = `
      Bạn là một mô hình phân loại câu hỏi. Dựa trên nội dung đề bài:
      ${des} 
      ${req}

      hãy phân loại nó thành một trong hai loại:
      - "classify_request": nếu người dùng đang hỏi câu hỏi để làm rõ về đề bài như giải thích test case mẫu, không liên quan đến cách làm.
      - "solve_request": nếu người dùng đang hỏi câu hỏi liên quan đến cách giải của bài tập.
      - "chat": nếu người dùng hỏi câu hỏi không liên quan đến đề bài trên.
      Câu hỏi: "${text}"
      Phân loại:
    `;


      const API_KEY = "AIzaSyBPfVw0jI5e6dpmg8BY4tNbVFPzGFfN6wI";
      const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      });

      const data = await res.json();
      const classification = data.candidates?.[0]?.content?.parts?.[0]?.text?.toLowerCase()?.trim() || "other";
      return classification;
    }

    // SỰ KIỆN KHI NHẤN GỬI
    sendBtn.addEventListener("click", async () => {
      const text = chatInput.value.trim();
      if (!text) return;

      // hiển thị user msg
      const userMsg = document.createElement("div");
      userMsg.className = "ptit-message ptit-user";
      userMsg.innerHTML = `<div class="ptit-text">${text}</div>`;
      chatBody.appendChild(userMsg);
      chatInput.value = "";
      chatBody.scrollTop = chatBody.scrollHeight;
      saveChat();

      const time_left = document.querySelector("#timeleft");
      if (!time_left) {
        botChat("Xin lỗi, tôi không thể trả lời bạn ngoài giờ kiểm tra.");
        saveChat();
        return;
      }

      // phân loại ý định bằng Gemini
      const intent = await classifyIntentWithGemini(text);
      let fullPrompt = text;

      console.log(`intent: ${intent}`)
      if (intent == "solve_request") {
        botChat("Xin lỗi, tôi không thể đưa bạn cách làm trong giờ kiểm tra");
        saveChat();
        return;
      }
      else if (intent === "classify_request") {
        const des = document.querySelector(".submit__des")?.innerText.trim() || "";
        const req = document.querySelector(".submit__req")?.innerText.trim() || "";

        if (des || req) {
          fullPrompt = `Hãy đọc bài toán này: "${des} ${req}" và yêu cầu là: "${text}".`;
        }
      } else {
        // console.log("alo")
        botChat("Xin lỗi, tôi không thể trả lời.");
        saveChat();
        return;
      }

      await callGeminiAPI(fullPrompt);
    });

    loadChat();
  })();
else
  (function () {
    console.log("PTIT Chat Extension: Content script đang chạy...");
    // ===== Constants =====
    const COMMAND_KEYWORDS = [
      'giải bài tập', 'giải bài', 'giai bai', 'giai bai tap', 'solve',
      'làm bài', 'lam bai', 'giải cho tôi', 'giai cho toi', 'giải bài này',
      'giai bai nay', 'giải cho tôi bài tập này', 'giai cho toi bai tap nay',
      'giải bài tập này', 'giai bai tap nay', 'làm bài này', 'lam bai nay',
      'giúp tôi giải', 'giup toi giai', 'hướng dẫn giải', 'huong dan giai'
    ];

    const SELECTORS = {
      problem: {
        nav: ['.submit__nav', '.submit_nav', '[class*="nav"]'],
        description: ['.submit__des', '.submit_des', '[class*="des"]', '.problem-description', '.question-description'],
        requirements: ['.submit__req', '.submit_req', '[class*="req"]', '.problem-requirements', '.question-requirements'],
        constraints: ['.submit__pad', '.submit_pad', '[class*="pad"]', '.constraints', '.problem-constraints'],
        examples: ['.card-body', '.examples', '.problem-examples', '.test-cases']
      },
      user: {
        name: [
          ".nav__profile__menu__name", ".nav__profile_menu_name",
          "#nav_profile .nav__profile__menu__name", "#nav_profile .nav__profile_menu_name",
          '[class*="profile__menu__name"]', '[class*="profile_menu_name"]'
        ],
        code: [
          ".nav__profile__menu__code", ".nav__profile_menu_code",
          "#nav_profile .nav__profile__menu__code", "#nav_profile .nav__profile_menu_code",
          '[class*="profile__menu__code"]', '[class*="profile_menu_code"]'
        ]
      }
    };

    function logInfo(message, ...args) { console.log(`PTIT Chat Extension: ${message}`, ...args); }
    function logWarn(message, ...args) { console.warn(`PTIT Chat Extension: ${message}`, ...args); }
    function logError(message, ...args) { console.error(`PTIT Chat Extension: ${message}`, ...args); }

    // Đợi DOM load hoàn toàn
    function waitForDOM() {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initChat);
      } else {
        initChat();
      }
    }

    function initChat() {
      console.log("PTIT Chat Extension: Khởi tạo chat...");

      const existingChat = document.getElementById("ptit-chat");
      if (existingChat) {
        console.log("PTIT Chat Extension: Chat đã tồn tại, bỏ qua.");
        return;
      }

      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'styles.css';
      document.head.appendChild(link);
      let token = null;
      let userName = "";
      let studentCode = "";

      // ======== LẤY THÔNG TIN NGƯỜI DÙNG TỪ TRANG ========
      function getUserInfoFromPage() {
        const getBySelectors = (selectors) => {
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText && el.innerText.trim()) return el.innerText.trim();
          }
          return "";
        };

        const nameText = getBySelectors(SELECTORS.user.name);
        const codeText = getBySelectors(SELECTORS.user.code);

        if (nameText) userName = nameText; else userName = "Unknown";
        if (codeText) studentCode = codeText; else studentCode = "Unknown";
        logInfo("User Info:", { userName, studentCode });
      }

      // Một số trang render trễ menu profile => retry để lấy được thông tin
      setTimeout(getUserInfoFromPage, 800);
      setTimeout(getUserInfoFromPage, 2000);

      getUserInfoFromPage();

      // ======== TẠO GIAO DIỆN CHAT ========
      const chatContainer = document.createElement("div");
      chatContainer.id = "ptit-chat";
      chatContainer.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      width: 60px;
      height: 60px;
      transition: all 0.3s ease;
    `;

      chatContainer.innerHTML = `
      <div class="ptit-box">
        <div class="ptit-header" id="ptit-header">
          <div class="ptit-icon" id="ptit-icon">🤖</div>
          <div class="ptit-status" id="ptit-status">🔴</div>
        </div>
        <div class="ptit-body" id="ptit-chat-body" style="display: none;">
          <div class="ptit-message ptit-bot">
            <div class="ptit-text">Xin chào ${userName || ""}, mình là PTIT, mình có thể giúp gì cho bạn?</div>
            <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
          </div>
        </div>
        <div class="ptit-footer" id="ptit-footer" style="display: none;">
          <input id="ptit-chat-input" class="ptit-input" placeholder="Nhập nội dung..." />
          <button id="ptit-send-btn" class="ptit-send-btn">➤</button>
        </div>
      </div>
      <style>
/* Container chính */
#ptit-chat {
  position: fixed !important;
  top: 20px !important;
  right: 20px !important;
  z-index: 10000 !important;
  width: 60px !important;
  height: 60px !important;
  max-width: 60px !important;
  box-shadow: 0 0 15px rgba(0,0,0,0.2) !important;
  border-radius: 12px !important;
  overflow: hidden !important;
  font-family: "Segoe UI", sans-serif !important;
  background-color: #fff !important;
  border: 1px solid #ccc !important;
  transition: all 0.3s ease !important;
}

/* Khi chat được mở rộng */
#ptit-chat.expanded {
  width: 500px !important;
  height: 600px !important;
  max-width: 90vw !important;
}

/* Hộp chính */
.ptit-box {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 100%;
}

/* Header */
.ptit-header {
  background-color: #d9272e;
  color: white;
  padding: 15px;
  font-size: 18px;
  font-weight: bold;
  text-align: center;
  letter-spacing: 0.5px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  min-height: 50px;
  flex-shrink: 0;
}

.ptit-status {
  font-size: 20px;
  cursor: help;
  user-select: none;
}

/* Icon mode */
.ptit-icon {
  font-size: 28px;
  cursor: pointer;
  user-select: none;
}

/* Minimize button */
.ptit-minimize-btn {
  background: none;
  border: none;
  color: white;
  font-size: 20px;
  cursor: pointer;
  padding: 0;
  margin: 0;
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.ptit-minimize-btn:hover {
  background-color: rgba(255, 255, 255, 0.2);
}

/* Khu vực tin nhắn */
.ptit-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background-color: #fafafa;
  min-height: 0;
  display: none;
  opacity: 0;
  transition: opacity 0.3s ease;
}

#ptit-chat.expanded .ptit-body {
  display: block;
  min-height: 400px;
  opacity: 1;
}

/* Footer */
.ptit-footer {
  display: none;
  padding: 15px;
  border-top: 1px solid #eee;
  background-color: #f9f9f9;
  flex-shrink: 0;
  opacity: 0;
  transition: opacity 0.3s ease;
}

#ptit-chat.expanded .ptit-footer {
  display: flex;
  opacity: 1;
}

/* Input người dùng */
.ptit-input {
  flex: 1;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  outline: none;
  font-size: 16px;
  min-height: 45px;
}

.ptit-input:focus {
  border-color: #d9272e;
  box-shadow: 0 0 0 2px rgba(217, 39, 46, 0.2);
}

/* Nút gửi */
.ptit-send-btn {
  margin-left: 12px;
  padding: 12px 18px;
  background-color: #d9272e;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
  font-size: 18px;
  min-height: 45px;
  transition: background-color 0.2s;
}

.ptit-send-btn:hover {
  background-color: #b71c1c;
}

/* Tin nhắn */
.ptit-message {
  display: flex;
  margin-bottom: 20px;
  align-items: flex-start;
}

.ptit-user {
  justify-content: flex-end;
}

.ptit-bot {
  justify-content: flex-start;
}

.ptit-text {
  padding: 15px 20px;
  border-radius: 15px;
  max-width: 80%;
  line-height: 1.6;
  word-wrap: break-word;
  font-size: 15px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.ptit-user .ptit-text {
  background-color: #e6f7ff;
  color: #333;
}

.ptit-bot .ptit-text {
  background-color: #d9272e;
  color: white;
}

.ptit-avatar {
  width: 32px;
  height: 32px;
  margin-left: 12px;
  align-self: flex-start;
  flex-shrink: 0;
}

/* Tùy chỉnh thanh cuộn */
.ptit-body::-webkit-scrollbar {
  width: 6px;
}
.ptit-body::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 3px;
}

/* Code blocks */
.ptit-code-block {
  background-color: #f4f4f4;
  border: 1px solid #ddd;
  border-radius: 6px;
  padding: 12px;
  margin: 8px 0;
  overflow-x: auto;
  font-family: 'Courier New', monospace;
  font-size: 13px;
  line-height: 1.4;
}

.ptit-inline-code {
  background-color: #f4f4f4;
  border: 1px solid #ddd;
  border-radius: 3px;
  padding: 2px 6px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
}

/* Responsive */
@media (max-width: 768px) {
  #ptit-chat {
    max-width: 95vw !important;
    right: 10px !important;
    left: 10px !important;
  }
  
  #ptit-chat.expanded {
    width: calc(100vw - 20px) !important;
    height: 70vh !important;
    max-width: calc(100vw - 20px) !important;
  }
  
  .ptit-box {
    min-height: 70vh;
  }
  
  .ptit-body {
    min-height: 50vh;
    padding: 15px;
  }
  
  .ptit-header {
    padding: 12px;
    font-size: 16px;
  }
  
  .ptit-text {
    max-width: 85%;
    font-size: 14px;
    padding: 12px 16px;
  }
  
  .ptit-input {
    font-size: 16px; /* Prevent zoom on iOS */
    padding: 10px 12px;
  }
}


      </style>
    `;

      document.body.appendChild(chatContainer);
      logInfo("Chat interface đã được inject!");

      const chatBody = document.getElementById("ptit-chat-body");
      const chatInput = document.getElementById("ptit-chat-input");
      const sendBtn = document.getElementById("ptit-send-btn");
      const ptitHeader = document.getElementById("ptit-header");
      const ptitIcon = document.getElementById("ptit-icon");
      const ptitFooter = document.getElementById("ptit-footer");

      // ======== QUẢN LÝ TRẠNG THÁI CHAT ========
      let isChatExpanded = false;

      function expandChat() {
        if (isChatExpanded) return;

        logInfo("Mở rộng chat...");
        isChatExpanded = true;

        // Thêm class expanded để CSS hoạt động
        chatContainer.classList.add("expanded");

        // Thay đổi kích thước container - tăng kích thước để dễ đọc
        chatContainer.style.width = "500px";
        chatContainer.style.height = "600px";
        chatContainer.style.maxWidth = "90vw";

        // Hiển thị chat body và footer
        chatBody.style.display = "block";
        ptitFooter.style.display = "flex";

        // Thay đổi header
        ptitHeader.innerHTML = `
        <span>Giải đáp thắc mắc cùng PTIT</span>
        <div class="ptit-status" id="ptit-status">🔴</div>
        <button class="ptit-minimize-btn" id="ptit-minimize-btn">➖</button>
      `;

        // Cập nhật status element reference
        const statusEl = document.getElementById("ptit-status");
        if (statusEl) {
          updateConnectionStatus(false); // Reset status
        }

        // Thêm event listener cho nút minimize
        const minimizeBtn = document.getElementById("ptit-minimize-btn");
        if (minimizeBtn) {
          minimizeBtn.addEventListener("click", collapseChat);
        }

        // Bắt đầu lấy token và kết nối
        getTokenFromServer();

        logInfo("Chat đã được mở rộng");
      }

      function collapseChat() {
        if (!isChatExpanded) return;

        logInfo("Thu nhỏ chat...");
        isChatExpanded = false;

        // Thu hồi token trước khi thu nhỏ (không cần await vì không quan trọng)
        releaseToken().catch(error => { logWarn("Lỗi khi thu hồi token (không ảnh hưởng đến UI):", error); });

        // Loại bỏ class expanded
        chatContainer.classList.remove("expanded");

        // Thay đổi kích thước container
        chatContainer.style.width = "60px";
        chatContainer.style.height = "60px";
        chatContainer.style.maxWidth = "60px";

        // Ẩn chat body và footer
        chatBody.style.display = "none";
        ptitFooter.style.display = "none";

        // Thay đổi header về dạng icon
        ptitHeader.innerHTML = `
        <div class="ptit-icon" id="ptit-icon">🤖</div>
        <div class="ptit-status" id="ptit-status">🔴</div>
      `;

        // Reset token ngay lập tức để UI responsive
        token = null;

        logInfo("Chat đã được thu nhỏ");
      }

      // Thêm event listener cho header để mở chat
      ptitHeader.addEventListener("click", (e) => {
        // Không mở chat nếu click vào status hoặc minimize button
        if (e.target.classList.contains("ptit-status") ||
          e.target.classList.contains("ptit-minimize-btn")) {
          return;
        }
        expandChat();
      });

      function saveChat() {
        localStorage.setItem("ptit-chat-history", chatBody.innerHTML);
      }

      function loadChat() {
        const saved = localStorage.getItem("ptit-chat-history");
        if (saved) {
          chatBody.innerHTML = saved;
        }
      }

      // ======== KIỂM TRA KẾT NỐI SERVER ========
      async function checkServerConnection() {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 3000); // 3 giây timeout

          try {
            const res = await fetch("http://localhost:3000/health", {
              method: "GET",
              signal: controller.signal
            });

            clearTimeout(timeoutId);
            return res.ok;
          } catch (fetchError) {
            clearTimeout(timeoutId);
            if (fetchError.name === 'AbortError') {
              logWarn("Health check bị timeout");
            } else {
              logWarn("Không thể kết nối server:", fetchError);
            }
            return false;
          }
        } catch (error) {
          logWarn("Lỗi khi kiểm tra kết nối server:", error);
          return false;
        }
      }

      // ======== CẬP NHẬT TRẠNG THÁI KẾT NỐI ========
      function updateConnectionStatus(isConnected) {
        const statusEl = document.getElementById("ptit-status");
        if (statusEl) {
          if (isConnected) {
            statusEl.textContent = "🟢";
            statusEl.title = "Đã kết nối server";
          } else {
            statusEl.textContent = "🔴";
            statusEl.title = "Không thể kết nối server";
          }
        }
      }

      // ======== LẤY TOKEN TỪ SERVER ========
      async function getTokenFromServer() {
        // Chỉ lấy token khi chat được mở rộng
        if (!isChatExpanded) {
          console.log("PTIT Chat Extension: Chat chưa mở, không lấy token");
          return;
        }

        try {
          logInfo("Đang kiểm tra kết nối server...");

          // Kiểm tra kết nối trước
          const isConnected = await checkServerConnection();
          updateConnectionStatus(isConnected);

          if (!isConnected) {
            throw new Error("Không thể kết nối server");
          }

          logInfo("Đang lấy token...");
          const res = await fetch("http://localhost:3000/get-token", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              studentCode: studentCode || "unknown",
              name: userName || "Unknown"
            })
          });

          if (!res.ok) {
            throw new Error(`Server trả về lỗi: ${res.status}`);
          }

          const data = await res.json();
          token = data.token;
          logInfo("Token được cấp:", token);

          // Hiển thị thông báo thành công
          const successMsg = document.createElement("div");
          successMsg.className = "ptit-message ptit-bot";
          successMsg.innerHTML = `
          <div class="ptit-text">✅ Đã kết nối server thành công! Bạn có thể bắt đầu chat.</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(successMsg);

        } catch (error) {
          logError("Không lấy được token từ server:", error);
          updateConnectionStatus(false);
          // Hiển thị thông báo lỗi cho user
          const errorMsg = document.createElement("div");
          errorMsg.className = "ptit-message ptit-bot";
          errorMsg.innerHTML = `
          <div class="ptit-text">⚠️ Không thể kết nối server. Hãy đảm bảo backend đang chạy tại localhost:3000</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(errorMsg);
        }
      }

      // ======== THU HỒI TOKEN ========
      async function releaseToken() {
        if (!token) return;

        try {
          logInfo("Đang thu hồi token...");

          // Kiểm tra server có còn hoạt động không
          const isConnected = await checkServerConnection();
          if (!isConnected) {
            logInfo("Server không hoạt động, bỏ qua việc thu hồi token");
            token = null; // Reset token ngay cả khi server không hoạt động
            return;
          }

          const res = await fetch("http://localhost:3000/release-token", {
            method: "POST",
            headers: { "Content-Type": "application/json;charset=UTF-8" },
            body: JSON.stringify({ token, studentCode: studentCode || "unknown" }),
            keepalive: true
          });

          if (res.ok) {
            logInfo("Đã thu hồi token thành công.");
            token = null; // Reset token
          } else {
            // Thêm logging chi tiết để debug
            let errorText = "";
            try {
              const ct = res.headers.get('content-type') || '';
              if (ct.includes('application/json')) {
                const j = await res.clone().json();
                errorText = JSON.stringify(j);
              } else {
                errorText = await res.text();
              }
            } catch (e) {
              errorText = `Không đọc được body: ${e?.message || e}`;
            }
            logWarn(`Server trả về lỗi khi thu hồi token. status=${res.status} statusText=${res.statusText} body=${errorText}`);
            // Reset token ngay cả khi có lỗi
            token = null;
          }
        } catch (error) {
          logInfo("Không thể thu hồi token (server có thể đã tắt):", error.message);
          // Không hiển thị lỗi này cho user vì không quan trọng
          token = null; // Reset token ngay cả khi có lỗi
        }
      }

      // CHỈ THU HỒI TOKEN KHI:
      // 1. User click nút thu nhỏ chat (đã có trong collapseChat function)
      // 2. User thực sự rời trang (không phải refresh)

      // Thu hồi token khi user thực sự rời trang
      window.addEventListener("beforeunload", (e) => {
        // Chỉ thu hồi token nếu chat đang mở rộng và có token
        if (isChatExpanded && token) {
          logInfo("User rời trang, thu hồi token...");
          // Sử dụng sendBeacon để gửi request khi page unload
          const data = JSON.stringify({ token, studentCode: studentCode || "unknown" });
          const success = navigator.sendBeacon("http://localhost:3000/release-token", data);
          if (success) {
            logInfo("Đã gửi request thu hồi token thành công");
          } else {
            logWarn("Không thể gửi request thu hồi token");
          }
        }
      });

      // KHÔNG THU HỒI TOKEN KHI:
      // - Chuyển tab (visibilitychange)
      // - Refresh trang (pagehide với persisted = true)
      // - Các hành động khác

      console.log("PTIT Chat Extension: Token chỉ được thu hồi khi rời trang hoặc thu nhỏ chat");

      // ======== PARSE MARKDOWN ========
      function parseMarkdown(md) {
        md = md.replace(/```([\s\S]*?)```/g, '<pre class="ptit-code-block"><code>$1</code></pre>');
        md = md.replace(/`([^`]+)`/g, '<code class="ptit-inline-code">$1</code>');
        md = md.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        md = md.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        md = md.replace(/\n(\d+)\. /g, '<br>$1. ');
        md = md.replace(/\n- /g, '<br>- ');
        md = md.replace(/\n/g, '<br>');
        return md;
      }

      // ======== NHẬN DIỆN LỆNH VÀ ĐỌC ĐỀ BÀI TRÊN TRANG PTIT ========
      function isQuestionPage() {
        return window.location.href.includes('/student/question/');
      }

      function matchesSolveCommand(text) {
        const t = (text || '').toLowerCase();
        return (
          t.includes('giải bài tập') ||
          t.includes('giải bài') ||
          t.includes('giai bai') ||
          t.includes('giai bai tap') ||
          t.includes('solve') ||
          t.includes('làm bài') ||
          t.includes('lam bai') ||
          t.includes('giải cho tôi') ||
          t.includes('giai cho toi') ||
          t.includes('giải bài này') ||
          t.includes('giai bai nay') ||
          t.includes('giải cho tôi bài tập này') ||
          t.includes('giai cho toi bai tap nay') ||
          t.includes('giải bài tập này') ||
          t.includes('giai bai tap nay') ||
          t.includes('làm bài này') ||
          t.includes('lam bai nay') ||
          t.includes('giúp tôi giải') ||
          t.includes('giup toi giai') ||
          t.includes('hướng dẫn giải') ||
          t.includes('huong dan giai')
        );
      }

      function extractProblemSections() {
        const getText = (selector) => {
          const el = document.querySelector(selector);
          return el ? el.innerText.trim() : '';
        };

        // Thử nhiều selector khác nhau để tìm nội dung đề bài
        const selectors = {
          nav: ['.submit__nav', '.submit_nav', '[class*="nav"]'],
          description: ['.submit__des', '.submit_des', '[class*="des"]', '.problem-description', '.question-description'],
          requirements: ['.submit__req', '.submit_req', '[class*="req"]', '.problem-requirements', '.question-requirements'],
          constraints: ['.submit__pad', '.submit_pad', '[class*="pad"]', '.constraints', '.problem-constraints'],
          examples: ['.card-body', '.examples', '.problem-examples', '.test-cases']
        };

        const result = {
          nav: '',
          description: '',
          requirements: '',
          constraints: '',
          examples: '',
          url: window.location.href
        };

        // Tìm nội dung cho mỗi phần
        Object.keys(selectors).forEach(key => {
          for (const selector of selectors[key]) {
            const text = getText(selector);
            if (text && text.length > 10) { // Chỉ lấy text có độ dài hợp lý
              result[key] = text;
              break;
            }
          }
        });

        // Nếu không tìm thấy theo selector cụ thể, thử tìm theo text content
        if (!result.description) {
          const allText = document.body.innerText;
          const lines = allText.split('\n').map(line => line.trim()).filter(line => line.length > 20);

          // Tìm dòng có vẻ là mô tả bài tập
          for (const line of lines) {
            if (line.includes('bài') || line.includes('bai') || line.includes('problem') || line.includes('đề') || line.includes('de')) {
              if (!result.description) {
                result.description = line;
              } else if (!result.requirements) {
                result.requirements = line;
              }
            }
          }
        }

        console.log('PTIT Extension: Đã đọc đề bài:', result);
        return result;
      }

      function buildSolvePrompt(problem, userIntentText) {
        const parts = [];
        parts.push('Bạn là trợ lý lập trình chuyên nghiệp. Hãy giải bài tập dưới đây bằng tiếng Việt, đưa ra phân tích chi tiết, thuật toán và mã nguồn hoàn chỉnh.');
        parts.push(`Nguồn bài: ${problem.url}`);

        if (problem.nav) parts.push(`📋 Thông tin bài tập: ${problem.nav}`);
        if (problem.description) parts.push(`📝 Mô tả đề bài: ${problem.description}`);
        if (problem.requirements) parts.push(`✅ Yêu cầu: ${problem.requirements}`);
        if (problem.constraints) parts.push(`🔒 Ràng buộc: ${problem.constraints}`);
        if (problem.examples) parts.push(`📊 Ví dụ/Test cases: ${problem.examples}`);

        parts.push(`\n🎯 Yêu cầu đầu ra:
1) Tóm tắt đề bài một cách rõ ràng
2) Phân tích ý tưởng và thuật toán giải quyết
3) Code hoàn chỉnh (ưu tiên C++/Java/Python nếu đề không chỉ rõ)
4) Giải thích code từng phần
5) Độ phức tạp thời gian và không gian
6) Kiểm thử với ví dụ cụ thể nếu có

Hãy viết code rõ ràng, có comment và dễ hiểu.`);

        if (userIntentText && !matchesSolveCommand(userIntentText)) {
          parts.push(`\n💬 Ghi chú từ người dùng: ${userIntentText}`);
        }

        const finalPrompt = parts.join('\n\n');
        console.log('PTIT Extension: Prompt được tạo:', finalPrompt);
        return finalPrompt;
      }

      // ======== GỌI API BACKEND (Gemini trả lời) ========
      async function callGeminiAPI(question) {
        const API_URL = "http://localhost:3000/api/ask";
        console.log("=== CALL GEMINI API ===");
        console.log("API URL:", API_URL);
        console.log("Question:", question);
        console.log("Token:", token);

        if (!token) {
          console.warn("PTIT Chat Extension: Chưa có token, không thể gửi request.");
          const errorMsg = document.createElement("div");
          errorMsg.className = "ptit-message ptit-bot";
          errorMsg.innerHTML = `
          <div class="ptit-text">⚠️ Chưa có token. Hãy đợi kết nối server...</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(errorMsg);
          return;
        }

        try {
          console.log("PTIT Chat Extension: Đang gửi câu hỏi:", question);
          console.log("Request body:", { prompt: question, token });

          const res = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt: question, token }),
          });

          console.log("Response status:", res.status);
          console.log("Response ok:", res.ok);

          if (!res.ok) {
            const errorText = await res.text();
            console.error("Server error response:", errorText);
            throw new Error(`Server error: ${res.status} - ${errorText}`);
          }

          const data = await res.json();
          console.log("Response data:", data);

          const reply = data.reply || "Không có phản hồi.";
          console.log("Extracted reply:", reply);

          if (reply === "Không có phản hồi.") {
            console.warn("PTIT Chat Extension: Reply là 'Không có phản hồi'");
            const errorMsg = document.createElement("div");
            errorMsg.className = "ptit-message ptit-bot";
            errorMsg.innerHTML = `
            <div class="ptit-text">⚠️ Gemini API trả về 'Không có phản hồi'. Có thể do:<br>
            • API key hết hạn<br>
            • Lỗi kết nối Gemini<br>
            • Câu hỏi không hợp lệ</div>
            <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
          `;
            chatBody.appendChild(errorMsg);
            return;
          }

          // Hiển thị trả lời
          const botMsg = document.createElement("div");
          botMsg.className = "ptit-message ptit-bot";
          botMsg.innerHTML = `
          <div class="ptit-text">${parseMarkdown(reply)}</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(botMsg);
          chatBody.scrollTop = chatBody.scrollHeight;
          saveChat();
          console.log("PTIT Chat Extension: Đã nhận phản hồi từ Gemini");
        } catch (error) {
          console.error("PTIT Chat Extension: Lỗi khi gọi Gemini:", error);
          const errorMsg = document.createElement("div");
          errorMsg.className = "ptit-message ptit-bot";
          errorMsg.innerHTML = `
          <div class="ptit-text">❌ Lỗi: ${error.message}<br>
          Hãy kiểm tra console để xem chi tiết lỗi.</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(errorMsg);
        }
      }

      // ======== SỰ KIỆN GỬI ========
      sendBtn.addEventListener("click", async () => {
        const text = chatInput.value.trim();
        if (!text) return;

        // Hiển thị tin nhắn người dùng
        const userMsg = document.createElement("div");
        userMsg.className = "ptit-message ptit-user";
        userMsg.innerHTML = `<div class="ptit-text">${text}</div>`;
        chatBody.appendChild(userMsg);
        chatInput.value = "";
        chatBody.scrollTop = chatBody.scrollHeight;
        saveChat();

        // Nếu đang ở trang bài tập PTIT và người dùng ra lệnh giải bài,
        // tự động đọc nội dung từ các thẻ .submit__nav, .submit__des, .submit__req
        let finalPrompt = text;
        if (isQuestionPage() && matchesSolveCommand(text)) {
          // Hiển thị thông báo đang đọc đề bài
          const readingMsg = document.createElement("div");
          readingMsg.className = "ptit-message ptit-bot";
          readingMsg.innerHTML = `
          <div class="ptit-text">🔍 Đang đọc đề bài từ trang... Vui lòng đợi!</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(readingMsg);
          chatBody.scrollTop = chatBody.scrollHeight;

          const problem = extractProblemSections();
          finalPrompt = buildSolvePrompt(problem, text);

          // Xóa thông báo đang đọc
          chatBody.removeChild(readingMsg);

          // Hiển thị thông báo đã đọc xong
          const successMsg = document.createElement("div");
          successMsg.className = "ptit-message ptit-bot";
          successMsg.innerHTML = `
          <div class="ptit-text">✅ Đã đọc xong đề bài! Đang gửi sang AI để giải...</div>
          <img src="${chrome.runtime.getURL("icon.png")}" class="ptit-avatar" />
        `;
          chatBody.appendChild(successMsg);
          chatBody.scrollTop = chatBody.scrollHeight;
        }

        await callGeminiAPI(finalPrompt);
      });

      // Enter key để gửi
      chatInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          sendBtn.click();
        }
      });

      loadChat();
      // Không tự động lấy token nữa, chỉ lấy khi user mở chat
      // getTokenFromServer();

      console.log("PTIT Chat Extension: Khởi tạo hoàn tất! Click vào icon để mở chat.");
    }

    // Bắt đầu
    waitForDOM();
  })();
