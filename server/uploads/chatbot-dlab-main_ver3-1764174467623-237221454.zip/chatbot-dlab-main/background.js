chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension đã được cài đặt.");
});
